function z = f(x,y,Dy)
  z = -(pi).^2.*exp(-y);
end