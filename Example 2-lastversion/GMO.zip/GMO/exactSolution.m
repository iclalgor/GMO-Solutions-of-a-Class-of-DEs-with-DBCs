function y = exactSolution(x)
   y = log(1+sin(pi*x));
end